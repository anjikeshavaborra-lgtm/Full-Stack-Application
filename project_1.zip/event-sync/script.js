// Fetch events every 3 seconds
setInterval(fetchEvents, 3000);

function fetchEvents() {
    fetch('fetch_events.php')
        .then(response => response.json())
        .then(data => {
            let output = '';
            data.forEach(event => {
                output += `
                    <div class="event">
                        <h3>${event.title}</h3>
                        <p>${event.description}</p>
                        <p>${event.event_date}</p>
                        <button onclick="deleteEvent(${event.id})">Delete</button>
                    </div>
                `;
            });
            document.getElementById('events').innerHTML = output;
        });
}

function addEvent() {
    let title = document.getElementById('title').value;
    let description = document.getElementById('description').value;
    let event_date = document.getElementById('event_date').value;

    fetch('add_event.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `title=${title}&description=${description}&event_date=${event_date}`
    })
    .then(() => fetchEvents());
}

function deleteEvent(id) {
    fetch('delete_event.php?id=' + id)
        .then(() => fetchEvents());
}

fetchEvents();