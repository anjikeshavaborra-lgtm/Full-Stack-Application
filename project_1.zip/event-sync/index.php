<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Real-Time Event Sync</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>Event Synchronization Engine</h1>
<a href="logout.php">
    <button>Logout</button>
</a>

<div class="form-container">
    <input type="text" id="title" placeholder="Event Title">
    <textarea id="description" placeholder="Event description" rows="2"></textarea>
    <input type="datetime-local" id="event_date">
    <button onclick="addEvent()">Add Event</button>
</div>

<div id="events"></div>

<script src="script.js"></script>
</body>
</html>