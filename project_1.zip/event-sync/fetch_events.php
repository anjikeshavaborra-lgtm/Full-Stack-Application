<?php
include 'db.php';

$result = $conn->query("SELECT * FROM events 
                        WHERE event_date >= NOW() 
                        ORDER BY event_date ASC");

$events = [];

while($row = $result->fetch_assoc()) {
    $events[] = $row;
}

echo json_encode($events);
?>