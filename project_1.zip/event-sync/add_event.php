<?php
include 'db.php';

$title = $_POST['title'];
$description = $_POST['description'];
$event_date = $_POST['event_date'];

$conn->query("INSERT INTO events (title, description, event_date) 
              VALUES ('$title', '$description', '$event_date')");
?>