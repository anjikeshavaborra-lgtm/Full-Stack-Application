<?php
$conn = new mysqli("localhost", "root", "", "event_sync");

if ($conn->connect_error) {
    die("Connection failed");
}
?>