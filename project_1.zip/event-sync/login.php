<?php
session_start();
include 'db.php';

$username = $_POST['username'];
$password = $_POST['password'];

$result = $conn->query("SELECT * FROM users 
                        WHERE username='$username' 
                        AND password='$password'");

if ($result->num_rows > 0) {
    $_SESSION['user'] = $username;
    header("Location: index.php");
} else {
    echo "Invalid Username or Password!";
}
?>